// netlify/functions/ai-brief.js
// ─────────────────────────────────────────────────────────────
// 상담 내용을 AI에 보내 쟁점·체크리스트를 받아 오는 중계 함수.
// API 키는 이 서버(Netlify 환경변수)에만 있고, 브라우저로 절대 내려가지 않습니다.
//
// [환경변수]  Netlify → Project configuration → Environment variables
//   GEMINI_API_KEY      Google AI Studio 에서 발급          (없으면 제미나이만 꺼짐)
//   ANTHROPIC_API_KEY   Anthropic Console 에서 발급         (없으면 클로드만 꺼짐)
//
//   GEMINI_MODEL        (선택) 기본 gemini-3.7-flash
//   CLAUDE_MODEL        (선택) 기본 claude-sonnet-5
//   AI_ALLOW_ORIGIN     (선택) 허용할 주소. 쉼표로 여러 개.
//                       예) https://admin.dawootax.kr,https://dawootax-office.netlify.app
//                       비워 두면 어디서나 부를 수 있습니다.
//   AI_SHARED_TOKEN     (선택) 정해 두면 요청에 x-app-token 헤더가 있어야 합니다.
//
// [확인]  브라우저로 이 함수 주소를 그냥 열면 키 등록 여부가 보입니다.
//         .../.netlify/functions/ai-brief
// ─────────────────────────────────────────────────────────────

// 모델은 쉼표로 여러 개 적을 수 있습니다. 앞의 것이 막히면 뒤의 것으로 넘어갑니다.
const GEMINI_MODELS = (process.env.GEMINI_MODEL || 'gemini-3.7-flash,gemini-3.6-flash,gemini-3.5-flash')
  .split(',').map(x => x.trim()).filter(Boolean);
const CLAUDE_MODELS = (process.env.CLAUDE_MODEL || 'claude-haiku-4-5,claude-sonnet-5')
  .split(',').map(x => x.trim()).filter(Boolean);
const GEMINI_MODEL = GEMINI_MODELS[0];
const CLAUDE_MODEL = CLAUDE_MODELS[0];

// Netlify 함수는 10초 안에 끝나야 한다. 그 안에서만 다른 모델을 시도한다.
const DEADLINE_MS = Number(process.env.AI_DEADLINE_MS || 8500);   // 전체 예산
const CALL_MS     = Number(process.env.AI_CALL_MS || 8000);       // 한 번 호출의 상한

// 정해진 시간을 넘기면 끊는다 (안 끊으면 Netlify가 10초에서 504 를 냅니다)
async function fetchIn(ms, url, opt){
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), ms);
  try { return await fetch(url, Object.assign({}, opt, { signal: ac.signal })); }
  finally { clearTimeout(t); }
}
const AUTH = st => [400, 401, 403].includes(st);   // 인증 계열
const MAX_CHARS    = 20000;   // 상담 내용이 이보다 길면 자릅니다

/* ── 흘려 받기 (streaming) ───────────────────────────────────
   AI는 글자를 한 번에 주지 않고 조금씩 흘려 보냅니다.
   끝까지 기다리다 시간이 다 되면 아무것도 못 건지지만,
   흘려 받으면 시간이 다 됐을 때 '거기까지'라도 건질 수 있습니다.
   그래서 「응답이 너무 늦어 끊었습니다」가 나오지 않습니다.        */
async function streamText(ms, url, opt, pick){
  const ac = new AbortController();
  const t  = setTimeout(() => ac.abort(), ms);
  let out = '', cut = false;
  try{
    const res = await fetch(url, Object.assign({}, opt, { signal: ac.signal }));
    if(!res.ok){
      const raw = await res.text().catch(() => '');
      let msg = 'HTTP ' + res.status;
      try{ const j = JSON.parse(raw); msg = (j.error && (j.error.message || j.error.type)) || msg; }catch(e){}
      return { ok: false, status: res.status, msg };
    }
    if(!res.body || typeof res.body.getReader !== 'function'){
      // 흘려 받기를 못 하는 환경이면 통째로 받는다
      const raw = await res.text();
      for(const line of raw.split('\n')) out += pick(line) || '';
      return { ok: true, text: out, cut: false };
    }
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = '';
    for(;;){
      const { done, value } = await reader.read();
      if(done) break;
      buf += dec.decode(value, { stream: true });
      let nl;
      while((nl = buf.indexOf('\n')) >= 0){
        const line = buf.slice(0, nl); buf = buf.slice(nl + 1);
        out += pick(line) || '';
      }
    }
    if(buf) out += pick(buf) || '';
    return { ok: true, text: out, cut: false };
  }catch(e){
    if(/abort/i.test(String(e.message || e))) cut = true;
    else if(!out) return { ok: false, status: 0, msg: String(e.message || e) };
    return { ok: true, text: out, cut: true, 시간초과: cut };
  }finally{ clearTimeout(t); }
}

// SSE 한 줄에서 글자만 뽑아내는 함수들
function pickGemini(line){
  if(!line.startsWith('data:')) return '';
  const s = line.slice(5).trim();
  if(!s || s === '[DONE]') return '';
  try{
    const j = JSON.parse(s);
    const c = ((j.candidates || [])[0] || {}).content || {};
    return ((c.parts || []).map(p => p.text || '').join(''));
  }catch(e){ return ''; }
}
function pickClaude(line){
  if(!line.startsWith('data:')) return '';
  const s = line.slice(5).trim();
  if(!s || s === '[DONE]') return '';
  try{
    const j = JSON.parse(s);
    if(j.type === 'content_block_delta' && j.delta && typeof j.delta.text === 'string') return j.delta.text;
    return '';
  }catch(e){ return ''; }
}

function baseHeaders(origin){
  const allow = String(process.env.AI_ALLOW_ORIGIN || '')
    .split(',').map(s => s.trim()).filter(Boolean);
  const ok = allow.length === 0 || (origin && allow.includes(origin));
  return {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': ok ? (origin || '*') : 'null',
    'Access-Control-Allow-Headers': 'Content-Type, x-app-token',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
    'Cache-Control': 'no-store',
    'Vary': 'Origin',
  };
}

/* ── 제미나이 ───────────────────────────────────────────── */
async function callGemini(system, user){
  const key = process.env.GEMINI_API_KEY;
  if(!key) throw new Error('제미나이 키가 등록되어 있지 않습니다 (GEMINI_API_KEY)');
  const payload = JSON.stringify({
    systemInstruction: { parts: [{ text: system }] },
    contents: [{ role: 'user', parts: [{ text: user }] }],
    generationConfig: { temperature: 0.2, maxOutputTokens: 1200 },
  });
  const t0 = Date.now(), left = () => DEADLINE_MS - (Date.now() - t0);
  let useQuery = false;   // 헤더 방식이 인증에서 막히면 옛 방식(?key=)으로 바꾼다
  let lastMsg = '';

  for(const model of GEMINI_MODELS){
    if(left() < 1500) break;
    const base = `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?alt=sse`;
    for(let pass = 0; pass < 2; pass++){        // 최대 2번 (두 번째는 인증 방식만 바꿔서)
      const url = useQuery ? base + '&key=' + encodeURIComponent(key) : base;
      const r = await streamText(Math.min(CALL_MS, Math.max(1500, left())), url, {
        method: 'POST',
        headers: useQuery ? { 'Content-Type': 'application/json' }
                          : { 'Content-Type': 'application/json', 'x-goog-api-key': key },
        body: payload,
      }, pickGemini);

      if(r.ok){
        if(r.text) return { text: r.text, model, usage: null, 잘림: !!r.cut };
        lastMsg = r.cut ? '응답이 너무 늦어 끊었습니다' : '빈 응답';
        break;
      }
      lastMsg = r.msg;
      const modelGone = /no longer available|not found|not supported|is deprecated/i.test(lastMsg);
      if(AUTH(r.status) && !modelGone && !useQuery){ useQuery = true; continue; }
      if(AUTH(r.status) && !modelGone) throw new Error('제미나이: ' + lastMsg);  // 키 문제
      break;   // 붐비거나 없는 모델이면 기다리지 말고 바로 다음 모델로
    }
  }
  throw new Error('제미나이: ' + (lastMsg || '연결 실패'));
}

/* ── 클로드 ─────────────────────────────────────────────── */
async function callClaude(system, user){
  const key = process.env.ANTHROPIC_API_KEY;
  if(!key) throw new Error('클로드 키가 등록되어 있지 않습니다 (ANTHROPIC_API_KEY)');
  const t0 = Date.now(), left = () => DEADLINE_MS - (Date.now() - t0);
  let lastMsg = '';

  for(const model of CLAUDE_MODELS){
    if(left() < 1500) break;
    const r = await streamText(Math.min(CALL_MS, Math.max(1500, left())), 'https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({
        model, max_tokens: 1200, system, stream: true,
        messages: [{ role: 'user', content: user }],
      }),
    }, pickClaude);

    if(r.ok){
      if(r.text) return { text: r.text, model, usage: null, 잘림: !!r.cut };
      lastMsg = r.cut ? '응답이 너무 늦어 끊었습니다' : '빈 응답';
      continue;
    }
    lastMsg = r.msg;
    const gone = /no longer available|not found|not_found|deprecated|does not exist/i.test(lastMsg);
    if(AUTH(r.status) && !gone) break;    // 키 문제면 다른 모델로 바꿔도 소용없다
  }
  throw new Error('클로드: ' + (lastMsg || '연결 실패'));
}

/* ── 지시문 ─────────────────────────────────────────────── */
function buildPrompt(body){
  const 분야 = String(body.분야 || '').slice(0, 40);
  const 내용 = String(body.내용 || '').slice(0, MAX_CHARS);
  const 목록 = Array.isArray(body.쟁점목록) ? body.쟁점목록.slice(0, 200) : [];
  const 기본 = String(body.기본정보 || '').slice(0, 2000);

  const system = [
    '당신은 한국의 상속·증여·양도소득·세무조사·조세불복 실무에 밝은 세무 전문가입니다.',
    '세무사가 상담을 마친 뒤 놓친 것이 없는지 훑어보는 것을 돕습니다.',
    '',
    '지켜야 할 것:',
    '1. 상담 내용에 없는 사실을 지어내지 마세요. 모르면 "확인필요"에 넣으세요.',
    '2. 세액을 계산하거나 결론을 단정하지 마세요. 판단과 책임은 세무사에게 있습니다.',
    '3. 법 조문·기간·비율·한도를 적을 때는 개정되었을 수 있으므로 단정하지 말고,',
    '   "주의" 칸에 무엇을 확인해야 하는지 적으세요. 확실하지 않으면 "법령"을 비워 두세요.',
    '4. 아래 [사무실 쟁점 목록]에 같은 뜻의 항목이 있으면 그 이름을 그대로 쓰세요.',
    '   목록에 없어도 실무상 중요하다면 새로 제안하세요. 목록에 갇히지 마세요.',
    '5. 이 사무실 목록은 오래되었을 수 있습니다. 목록과 다르게 보시면 "주의"에 적어 주세요.',
    '6. 한국어 존댓말로, 아주 짧게. 한 줄 55자 이내. 군더더기 없이 핵심만.',
    '7. 개수 — 요약 2줄, 쟁점 5개, 확인필요 4개, 서류 4개 이내. 넘기지 마세요.',
    '8. 중요한 것부터 먼저 쓰세요. 뒤가 잘려도 앞이 남도록.',
    '',
    '출력은 아래 JSON 하나만. 설명·머리말·코드펜스를 붙이지 마세요.',
    '{',
    '  "요약": ["사실관계 한 줄", "..."],',
    '  "쟁점": [{"t":"쟁점 이름","근거":"상담의 어느 대목 때문인지 한 줄",',
    '           "확신":"높음|보통|낮음","법령":"관련 조문(불확실하면 빈칸)",',
    '           "주의":"개정·요건을 확인해야 할 점(없으면 빈칸)"}],',
    '  "확인필요": ["고객에게 더 물어봐야 할 것 한 줄", "..."],',
    '  "서류": ["받아야 할 서류 이름", "..."]',
    '}',
  ].join('\n');

  const user = [
    `[분야] ${분야 || '미지정'}`,
    기본 ? `\n[기본 정보]\n${기본}` : '',
    '',
    '[사무실 쟁점 목록] — 참고용입니다. 해당하면 같은 이름을 쓰고, 없으면 새로 제안하세요.',
    목록.map(t => '- ' + t).join('\n'),
    '',
    '[상담 내용]',
    내용,
  ].filter(Boolean).join('\n');

  return { system, user };
}

/* 답변이 중간에 잘렸을 때, 마지막으로 완결된 데까지만 남기고 괄호를 닫아 살려 낸다 */
function repairJson(raw){
  let inStr = false, esc = false, safe = -1;
  for(let i = 0; i < raw.length; i++){
    const c = raw[i];
    if(inStr){
      if(esc){ esc = false; continue; }
      if(c === '\\'){ esc = true; continue; }
      if(c === '"') inStr = false;
      continue;
    }
    if(c === '"'){ inStr = true; continue; }
    if(c === '}' || c === ']') safe = i + 1;    // 값 하나가 끝난 자리
    else if(c === ',')         safe = i;        // 쉼표 앞까지는 완결
  }
  if(safe < 1) return null;
  let cut = raw.slice(0, safe).replace(/,\s*$/, '');
  // 남은 괄호를 세어 닫는다
  const stack = [];
  inStr = false; esc = false;
  for(const c of cut){
    if(inStr){
      if(esc){ esc = false; continue; }
      if(c === '\\'){ esc = true; continue; }
      if(c === '"') inStr = false;
      continue;
    }
    if(c === '"') inStr = true;
    else if(c === '{') stack.push('}');
    else if(c === '[') stack.push(']');
    else if(c === '}' || c === ']') stack.pop();
  }
  if(inStr) return null;
  while(stack.length) cut += stack.pop();
  return cut;
}

/* ── 응답에서 JSON만 뽑아내기 ───────────────────────────── */
function parseJson(text){
  let s = String(text || '').trim();
  s = s.replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '').trim();
  const a = s.indexOf('{'), b = s.lastIndexOf('}');
  if(a >= 0 && b > a) s = s.slice(a, b + 1);
  try{
    const o = JSON.parse(s);
    return {
      요약:     Array.isArray(o.요약) ? o.요약.map(String) : [],
      쟁점:     Array.isArray(o.쟁점) ? o.쟁점.filter(x => x && x.t).map(x => ({
                  t: String(x.t), 근거: String(x.근거 || ''), 확신: String(x.확신 || ''),
                  법령: String(x.법령 || ''), 주의: String(x.주의 || '') })) : [],
      확인필요: Array.isArray(o.확인필요) ? o.확인필요.map(String) : [],
      서류:     Array.isArray(o.서류) ? o.서류.map(String) : [],
    };
  }catch(e){
    // 잘린 답변이면 살려서 한 번 더
    const fixed = repairJson(s);
    if(fixed){
      try{
        const o = JSON.parse(fixed);
        return {
          요약:     Array.isArray(o.요약) ? o.요약.map(String) : [],
          쟁점:     Array.isArray(o.쟁점) ? o.쟁점.filter(x => x && x.t).map(x => ({
                      t: String(x.t), 근거: String(x.근거 || ''), 확신: String(x.확신 || ''),
                  법령: String(x.법령 || ''), 주의: String(x.주의 || '') })) : [],
          확인필요: Array.isArray(o.확인필요) ? o.확인필요.map(String) : [],
          서류:     Array.isArray(o.서류) ? o.서류.map(String) : [],
          잘림: true,
        };
      }catch(e2){}
    }
    return { 요약: [], 쟁점: [], 확인필요: [], 서류: [], 원문: String(text || '').slice(0, 3000) };
  }
}

/* ── 진입점 ─────────────────────────────────────────────── */
exports.handler = async function(event){
  const h = (event.headers || {});
  const origin = h.origin || h.Origin || '';
  const headers = baseHeaders(origin);

  if(event.httpMethod === 'OPTIONS') return { statusCode: 204, headers, body: '' };

  // 자가진단 — 주소 뒤에 ?selftest=1 을 붙이면 실제로 AI를 한 번 불러 봅니다
  if(event.httpMethod === 'GET' && (event.queryStringParameters||{}).selftest){
    const out = {};
    const sys = '한 단어로만 답하세요.';
    const usr = '연결 확인. "정상" 이라고만 답하세요.';
    if(process.env.GEMINI_API_KEY){
      try{ const r = await callGemini(sys, usr); out.제미나이 = { 결과:'성공', 모델:r.model, 답:String(r.text).slice(0,40) }; }
      catch(e){ out.제미나이 = { 결과:'실패', 이유:String(e.message||e) }; }
    } else out.제미나이 = { 결과:'키 없음' };
    if(process.env.ANTHROPIC_API_KEY){
      try{ const r = await callClaude(sys, usr); out.클로드 = { 결과:'성공', 모델:r.model, 답:String(r.text).slice(0,40) }; }
      catch(e){ out.클로드 = { 결과:'실패', 이유:String(e.message||e) }; }
    } else out.클로드 = { 결과:'키 없음' };
    return { statusCode: 200, headers, body: JSON.stringify(out, null, 1) };
  }

  // 살아 있는지 확인용 — 브라우저로 그냥 열면 이 화면이 나옵니다
  if(event.httpMethod === 'GET'){
    return { statusCode: 200, headers, body: JSON.stringify({
      ok: true,
      함수: 'ai-brief',
      제미나이: process.env.GEMINI_API_KEY ? '키 등록됨 · ' + GEMINI_MODEL : '키 없음',
      클로드:   process.env.ANTHROPIC_API_KEY ? '키 등록됨 · ' + CLAUDE_MODEL : '키 없음',
      허용주소: process.env.AI_ALLOW_ORIGIN || '(제한 없음)',
      토큰검사: process.env.AI_SHARED_TOKEN ? '켜짐' : '꺼짐',
    }, null, 1) };
  }

  if(event.httpMethod !== 'POST'){
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'POST 요청만 받습니다.' }) };
  }

  const need = process.env.AI_SHARED_TOKEN;
  if(need && (h['x-app-token'] || h['X-App-Token']) !== need){
    return { statusCode: 401, headers, body: JSON.stringify({ error: '허가되지 않은 요청입니다.' }) };
  }

  let body;
  try{ body = JSON.parse(event.body || '{}'); }
  catch(e){ return { statusCode: 400, headers, body: JSON.stringify({ error: '요청 형식이 잘못되었습니다.' }) }; }

  if(!String(body.내용 || '').trim()){
    return { statusCode: 400, headers, body: JSON.stringify({ error: '상담 내용이 비어 있습니다.' }) };
  }

  const { system, user } = buildPrompt(body);
  const which = body.provider === 'both' ? ['gemini', 'claude']
              : body.provider === 'claude' ? ['claude'] : ['gemini'];

  const jobs = which.map(async p => {
    try{
      const r = p === 'claude' ? await callClaude(system, user) : await callGemini(system, user);
      const out = { provider: p, model: r.model, usage: r.usage, ...parseJson(r.text) };
      if(r.잘림) out.잘림 = true;
      return out;
    }catch(e){
      return { provider: p, error: String(e.message || e) };
    }
  });

  const results = await Promise.all(jobs);
  const allFailed = results.every(r => r.error);
  return {
    statusCode: allFailed ? 502 : 200,
    headers,
    body: JSON.stringify({ ok: !allFailed, results }),
  };
};

// 시험용 (테스트에서만 씁니다)
exports.__test = { streamText, pickGemini, pickClaude, parseJson, repairJson };
