// netlify/functions/get-submissions.js
// ─────────────────────────────────────────────────────────────
// 탈리(Tally)에 들어온 상담·견적 신청을 읽어 옵니다.
// 탈리 API 키는 이 서버(Netlify 환경변수)에만 있고 브라우저로 내려가지 않습니다.
//
// [환경변수]  Netlify → Project configuration → Environment variables
//   TALLY_API_KEY    탈리에서 발급한 키                    (필수)
//   TALLY_FORM_ID    폼 주소 tally.so/r/○○○○○○ 의 뒷부분   (없으면 q4qkq7)
//   TALLY_LIMIT      한 번에 가져올 건수                    (없으면 30)
//
// [확인]  브라우저로 이 주소를 열면 키 등록 여부가 보입니다.
//         .../.netlify/functions/get-submissions?ping=1
// ─────────────────────────────────────────────────────────────

const FORM_ID = process.env.TALLY_FORM_ID || 'q4qkq7';
const LIMIT   = process.env.TALLY_LIMIT   || '30';

const CORS = {
  'Content-Type': 'application/json; charset=utf-8',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, Accept',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Cache-Control': 'no-store',
};

exports.handler = async function (event) {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: CORS, body: '' };

  const key = process.env.TALLY_API_KEY;

  // 살아 있는지 확인용
  const q = (event.queryStringParameters || {});
  if (q.ping) {
    return { statusCode: 200, headers: CORS, body: JSON.stringify({
      ok: true,
      함수: 'get-submissions',
      탈리키: key ? '키 등록됨' : '키 없음 (TALLY_API_KEY)',
      폼번호: FORM_ID,
      건수: LIMIT,
    }, null, 1) };
  }

  if (!key) {
    return { statusCode: 500, headers: CORS, body: JSON.stringify({
      error: '탈리 키가 등록되어 있지 않습니다 (TALLY_API_KEY)' }) };
  }

  try {
    const res = await fetch(
      `https://api.tally.so/forms/${FORM_ID}/submissions?limit=${encodeURIComponent(LIMIT)}`,
      { headers: { Authorization: `Bearer ${key}` } }
    );
    if (!res.ok) {
      const text = await res.text();
      return { statusCode: res.status, headers: CORS, body: JSON.stringify({
        error: '탈리에서 자료를 받지 못했습니다', detail: text.slice(0, 500) }) };
    }
    const data = await res.json();
    return { statusCode: 200, headers: CORS, body: JSON.stringify(data) };
  } catch (err) {
    return { statusCode: 500, headers: CORS, body: JSON.stringify({ error: String(err.message || err) }) };
  }
};
